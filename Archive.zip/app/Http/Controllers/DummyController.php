<?php

namespace App\Http\Controllers;

class DummyController extends Controller
{
    public function __construct()
    {

    }

    public function test(){
        return 'hello world';
    }
}
?>